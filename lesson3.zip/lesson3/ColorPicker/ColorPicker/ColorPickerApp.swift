//
//  ColorPickerApp.swift
//  ColorPicker
//
//  Created by IACD-Air-7 on 2021/06/22.
//

import SwiftUI

@main
struct ColorPickerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
