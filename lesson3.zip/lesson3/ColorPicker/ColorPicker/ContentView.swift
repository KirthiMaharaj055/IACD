//
//  ContentView.swift
//  ColorPicker
//
//  Created by IACD-Air-7 on 2021/06/22.
//

import SwiftUI

struct ContentView: View {
    @State private var selectedColor = Color.black
    var body: some View {
        ScrollView {
            VStack(alignment: .center) {
                Text("Color Picker Demo").foregroundColor(selectedColor).font(.largeTitle)
                Image("pic").resizable().scaledToFit().frame(width: 300, height: 200).foregroundColor(selectedColor)
                ColorPicker("Pick a color", selection: $selectedColor).frame(width: 150, height: 150)
                Spacer()
            }.padding(.vertical, 70)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
