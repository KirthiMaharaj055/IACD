//
//  ContentView.swift
//  Calculate
//
//  Created by IACD-Air-7 on 2021/04/30.
//

import SwiftUI

enum CalculatorButton: String{
    case equals, add, subtract, multiply, divide
    
    var button: String{
        switch self {
            case .add: return "➕"
            case .subtract: return "➖"
            case .multiply: return "✖️"
            case .divide: return "➗"
            default:
                return "="
        }
    }
}

enum Operation: String {
    case plus = "➕"
     case minus = "➖"
    case multiply = "✖️"
    case divide = "➗"
    case none = "0"
    
    func doSymbols() -> String  {
        return self.rawValue
       }
}

struct ContentView: View {
    @State private var num1:String = ""
    @State private var num2:String = ""
    @State var finalValue:String = ""
    @State var currentOperation: Operation = .none
    
    
    let buttons:[[CalculatorButton]] = [
        
        [.add, .subtract],
        [.multiply, .divide],
        [.equals]
    ]
    var body: some View {
        ZStack {
            Image("99")
                .edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
                
            VStack {
                Text(num1 + " " + currentOperation.doSymbols() + " " + num2)
                    .font(.title)
                    .fontWeight(.bold)
                    .foregroundColor(Color.black)
                    .frame(width: 310, height: 50, alignment: .center )
                    .background(Color(red: 0.13, green: 0.44, blue: 0.58))
                    
                
                Text(finalValue)
                    .font(.title)
                    .fontWeight(.bold)
                    .foregroundColor(Color.orange)
                    .frame(width: 310, height: 50, alignment: .center )
                    .background(Color(red: 0.13, green: 0.44, blue: 0.58))
                    .padding()
                
                HStack {
                  Image(systemName: "number").foregroundColor(.gray)
                  TextField("Enter your first Number", text: $num1)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .frame(width: 280, height: 50)
                  }
                .padding()
                .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.gray, lineWidth: 1)
                    .padding()
                )
                
                HStack {
                  Image(systemName: "number").foregroundColor(.gray)
                  TextField("Enter your second Number", text: $num2)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .frame(width: 280, height: 50)
                  }
                .padding()
                .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.gray, lineWidth: 1)
                    .padding()
            )
                
                ForEach(buttons, id: \.self){
                    row in
                    HStack {
                        ForEach(row, id: \.self){
                            item in
                            Button(action: {
                                self.processExpression(exp: item)
                            }) {
                            ZStack {
                                Rectangle()
                                    .frame(width: 80, height: 30)
                                    .cornerRadius(40)
                                Text(item.button)
                                    .foregroundColor(Color.black)
                                    .padding()
                                    .font(.system(size: 20))
                                    .frame(width: 80, height: 30)
                                    .background(Color(red: 0.20, green: 0.67, blue: 0.88))
                                    .cornerRadius(40)
                            }
                        }
                        }
                    }
                }
            }
        }
    }
    
    
func processExpression(exp: CalculatorButton){
        
            switch exp {
                case .add , .subtract, .multiply, .equals:
                    if exp == .add{
                        currentOperation = .plus
                    }else if exp == .subtract{
                        currentOperation = .minus
                    }else if exp == .multiply {
                        currentOperation = .multiply
                    }else if exp == .divide{
                        currentOperation = .divide
                    }else if exp == .equals{
                        
                        let a = Int(self.num1)
                        let b = Int(self.num2)
                        
                        switch self.currentOperation {
                            case .plus:
                                self.finalValue = "\(a! + b!)"
                            case .minus:
                                self.finalValue = "\(a! - b!)"
                            case .multiply:
                                self.finalValue = "\(a! * b!)"
                            case .divide:
                                self.finalValue = "\(a! / b!)"
                            case .none:
                            break
                        }
                    }
                    
                default:
                    let number = exp.button
                    if self.finalValue == " " {
                        finalValue = number
                    }else{
                        self.finalValue = "\(self.finalValue)\(number)"
                    }
            }
            
    }
    
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
