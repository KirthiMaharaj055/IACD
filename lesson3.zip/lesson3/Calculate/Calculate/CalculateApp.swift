//
//  CalculateApp.swift
//  Calculate
//
//  Created by IACD-Air-7 on 2021/04/30.
//

import SwiftUI

@main
struct CalculateApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
