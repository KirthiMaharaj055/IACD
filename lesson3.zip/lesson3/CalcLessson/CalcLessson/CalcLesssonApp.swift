//
//  CalcLesssonApp.swift
//  CalcLessson
//
//  Created by IACD-Air-7 on 2021/04/22.
//

import SwiftUI

@main
struct CalcLesssonApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
