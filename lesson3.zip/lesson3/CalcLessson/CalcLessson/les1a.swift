//
//  les1a.swift
//  CalcLessson
//
//  Created by IACD-Air-7 on 2021/04/22.
//

import SwiftUI

struct les1a: View {
    var body: some View {
        VStack {
            HStack {
                ForEach(["7", "8", "9", "x"], id: \.self){
                    item in
                    Text(item)
                        .font(.system(size: 36))
                        .frame(width: 90, height: 90)
                }
            }
            HStack {
                ForEach(["7", "8", "9", "x"], id: \.self){
                    item in
                    Text(item)
                        .font(.system(size: 36))
                        .frame(width: 90, height: 90)
                }
            }
            
        }
    }
}

struct les1a_Previews: PreviewProvider {
    static var previews: some View {
        les1a()
    }
}
