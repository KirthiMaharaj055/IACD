//
//  ContentView.swift
//  CalcLessson
//
//  Created by IACD-Air-7 on 2021/04/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            HStack {
                Text("7")
                    .font(.system(size: 36))
                Text("8")
                    .font(.system(size: 36))
                Text("9")
                    .font(.system(size: 36))
                Text("x")
                    .font(.system(size: 36))
            }
            HStack {
                Text("4")
                    .font(.system(size: 36))
                Text("5")
                    .font(.system(size: 36))
                Text("6")
                    .font(.system(size: 36))
                Text("-")
                    .font(.system(size: 36))
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
