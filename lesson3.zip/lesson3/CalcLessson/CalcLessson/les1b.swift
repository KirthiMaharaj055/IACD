//
//  les1b.swift
//  CalcLessson
//
//  Created by IACD-Air-7 on 2021/04/22.
//

import SwiftUI

enum CalculatorButton: String {
    case zero, one, two, three, four, five, six, seven, eight, nine, decimal
    case equals, plus, minus, multiply, divide, negative
    case ac, plusMinus, percent
    
    var changes: String{
        switch self {
            case .zero: return "0"
            case .one: return "1"
            case .two: return "2"
            case .three: return "3"
            case .four: return "4"
            case .five: return "5"
            case .six: return "6"
            case .seven: return "7"
            case .eight: return "8"
            case .nine: return "9"
            case .equals: return "="
            case .plus: return "➕"
            case .minus: return "➖"
            case .multiply: return "✖️"
            case .divide: return "➗"
            case .percent: return "％"
            case .plusMinus: return "⁺∕˗"
            case .decimal: return ","
            default:
                return "AC"
        }
    }
    // start with colors
    var backgroundColor: Color {
        switch self {
            case .zero, .one, .two, .three, .four, .five, .six, .seven, .eight, .nine, .decimal:
                return Color(red: 0.96, green: 0.23, blue: 0.34)
            case .ac, .plusMinus, .percent:
                return Color(red: 1.00, green: 0.80, blue: 0.80)
            default:
                return Color(red: 1.00, green: 0.30, blue: 0.30)
        }
    }
}

enum Operation {
    case plus, minus, multiply, divide, none
}

struct les1b: View {
    
    @State var values = "0"
    @State var runningNumber = 0
    @State var currentOperation: Operation = .none
    
    let buttons: [[CalculatorButton]] = [
        [.ac, .plusMinus, .percent, .divide],
        [.seven, .eight, .nine, .multiply],
        [.four, .five, .six, .minus],
        [.one, .two, .three, .plus],
        [.zero, .decimal, .equals]
        
    ]

    var body: some View {
        ZStack(alignment: .bottom) {
            Color(red: 1.00, green: 0.72, blue: 0.72)
            .edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
            
            VStack(spacing: 12){
                HStack {
                    Text(values)
                        .foregroundColor(/*@START_MENU_TOKEN@*/.blue/*@END_MENU_TOKEN@*/)
                        .font(.system(size: 64))
                }
                .padding()
                
                ForEach(buttons, id: \.self){
                    row in
                    HStack(alignment: .center,spacing: 14) {
                        
                        ForEach(row, id: \.self){
                            item in
                            Button(action: {
                                self.didTap(button: item)
                            }) {
                                Text(item.changes)
                                    .font(.system(size: 32))
                                    .frame(
                                        width: self.buttonWidth(item: item),
                                        height: self.buttonHeight(),
                                        alignment: .center
                                    )
                                    .foregroundColor(.black)
                                    .background(item.backgroundColor)
                                    .cornerRadius(90)
                            }
                        }
                    }
                }
            }
        }
    }

func didTap(button: CalculatorButton) {
    switch button {
        case .plus, .minus, .multiply, .divide, .equals:
            if button == .plus {
                self.currentOperation = .plus
                self.runningNumber = Int(self.values) ?? 0
            }else if button == .minus {
                self.currentOperation = .minus
                self.runningNumber = Int(self.values) ?? 0
            }else if button == .multiply {
                self.currentOperation = .multiply
                self.runningNumber = Int(self.values) ?? 0
            }else if button == .divide {
                self.currentOperation = .divide
                self.runningNumber = Int(self.values) ?? 0
            }else if button == .equals {
                let runningValue = self.runningNumber
                let currentValue = Int(self.values) ?? 0
                switch self.currentOperation {
                    case .plus: self.values = "\(runningValue + currentValue)"
                    case .minus: self.values = "\(runningValue - currentValue)"
                    case .multiply: self.values = "\(runningValue * currentValue)"
                    case .divide: self.values = "\(runningValue / currentValue)"
                    case .none:
                    break
                }
            }
            if button != .equals {
                self.values = "0"
            }
        case .ac:
            self.values = "0"
            case .decimal, .plusMinus, .percent:
            break
        default:
            let number = button.changes
            if self.values == "0" {
                values = number
            }else{
                self.values = "\(self.values)\(number)"
            }
        }
    }

    func buttonWidth(item: CalculatorButton) -> CGFloat {
        if item == .zero {
            return ((UIScreen.main.bounds.width - (4*12)) / 4) * 2
        }
        return (UIScreen.main.bounds.width - (5*12)) / 4
    }
    func buttonHeight() -> CGFloat {
        return (UIScreen.main.bounds.width - (5*12)) / 4
    }
}
struct les1b_Previews: PreviewProvider {
    static var previews: some View {
        les1b()
    }
}
