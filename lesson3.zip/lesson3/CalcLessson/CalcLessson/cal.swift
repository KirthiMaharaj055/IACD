//
//  cal.swift
//  CalcLessson
//
//  Created by IACD-Air-7 on 2021/04/29.
//

import SwiftUI

enum CalculatorButtons: String {
    case zero, one, two, three, four, five, six, seven, eight, nine, decimal
    case equals, plus, minus, multiply, divide, negative
    case ac, plusMinus, percent
    
    var changes: String{
        switch self {
            case .zero: return "0"
            case .one: return "1"
            case .two: return "2"
            case .three: return "3"
            case .four: return "4"
            case .five: return "5"
            case .six: return "6"
            case .seven: return "7"
            case .eight: return "8"
            case .nine: return "9"
            case .equals: return "="
            case .plus: return "➕"
            case .minus: return "➖"
            case .multiply: return "✖️"
            case .divide: return "➗"
            case .percent: return "％"
            case .plusMinus: return "⁺∕˗"
            case .decimal: return ","
            
            default:
                return "AC"
        }
    }
    
    // start with colors
    var backgroundColor: Color {
        switch self {
            case .zero, .one, .two, .three, .four, .five, .six, .seven, .eight, .nine, .decimal:
                return Color(.darkGray)
            case .ac, .plusMinus, .percent:
                return Color(.lightGray)
            default:
                return .orange
        }
    }
}

enum Operations {

    case add, subtract, multiply, divide, none

}

struct cal: View {
    @State var value = "0"
    @State var runningNumber = 0
    @State var currentOperation: Operations = .none
    
    let buttons: [[CalculatorButtons]] = [
        [.ac, .plusMinus, .percent, .divide],
        [.seven, .eight, .nine, .multiply],
        [.four, .five, .six, .minus],
        [.one, .two, .three, .plus],
        [.zero, .decimal, .equals]
    ]
    var body: some View {
        ZStack {
            Color.black.edgesIgnoringSafeArea(.all)

            VStack {
                Spacer()
                
                HStack {
                    Spacer()
                    Text(value)
                        .bold()
                        .font(.system(size: 100))
                        .foregroundColor(.white)
                }
                .padding()

                ForEach(buttons, id: \.self) { row in
                    HStack(spacing: 12) {
                        ForEach(row, id: \.self) { item in
                            Button(action: {
                                self.didTap(button: item)
                            }) {
                                Text(item.rawValue)
                                    .font(.system(size: 32))
                                    .frame(
                                        width: self.buttonWidth(item: item),
                                        height: self.buttonHeight()
                                    )
                                    .background(item.backgroundColor)
                                    .foregroundColor(.white)
                                    .cornerRadius(self.buttonWidth(item: item)/2)
                            }
                        }
                    }
                    .padding(.bottom, 3)
                }
            }
        }
    }
}



struct cal_Previews: PreviewProvider {
    static var previews: some View {
        cal()
    }
}
