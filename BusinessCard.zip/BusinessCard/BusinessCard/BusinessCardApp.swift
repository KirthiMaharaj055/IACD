//
//  BusinessCardApp.swift
//  BusinessCard
//
//  Created by IACD-Air-7 on 2021/04/09.
//

import SwiftUI

@main
struct BusinessCardApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
