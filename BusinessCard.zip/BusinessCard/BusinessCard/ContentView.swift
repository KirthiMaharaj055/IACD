//
//  ContentView.swift
//  BusinessCard
//
//  Created by IACD-Air-7 on 2021/04/09.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
        ZStack {
            Color(red: 0.21, green: 0.23, blue: 0.28)
                .edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
            HStack {
                VStack {
                    HStack {
                        VStack {
                            Text("IOS Developer")
                                .font(.title)
                                .fontWeight(.bold)
                                .multilineTextAlignment(.center)
                                
                            Text("Kirthi Maharaj")
                                .font(.callout)
                                .fontWeight(.bold)
                        }
                        Image("kirthi")
                            .resizable()
                            .frame(width: 100, height: 100, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                            .clipShape(Circle())
                            .overlay(Circle().stroke(Color.black, lineWidth: 5))
                            .shadow(radius: 7)
                    }
                    .padding()
                    Divider()
                    RoundedRectangle(cornerRadius: 25)
                        .fill(Color.gray)
                        .frame(height: 50)
                        .overlay(
                        HStack{
                            Image(systemName: "envelope.circle")
                            Text("maharajkirthi@gmail.com")
                                .fontWeight(.ultraLight)
                                .foregroundColor(Color.black)
                                .italic()
                                .padding()
                        })
                    RoundedRectangle(cornerRadius: 25)
                        .fill(Color.gray)
                        .frame(height: 50)
                        .overlay(
                        HStack{
                            Image(systemName: "phone.circle")
                            Text("+27 745 319 999")
                                .fontWeight(.ultraLight)
                                .italic()
                                .padding()
                        })

                        NavigationLink(destination: Portfolio()) {
                            Text("Details")
                                .frame(width: 70, height: 70, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                                .font(.caption)
                                .font(.system(size: 20))
                                
                                .foregroundColor(Color.black)
                                
                            
                            
                        }
                }.background(LinearGradient(gradient: Gradient(colors: [Color.black, Color.gray, Color.black]), startPoint: /*@START_MENU_TOKEN@*/.leading/*@END_MENU_TOKEN@*/, endPoint: /*@START_MENU_TOKEN@*/.trailing/*@END_MENU_TOKEN@*/))
                        .cornerRadius(20)
                    
                }.padding()
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
