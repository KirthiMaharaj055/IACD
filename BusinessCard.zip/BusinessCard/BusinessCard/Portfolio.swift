//
//  Portfolio.swift
//  BusinessCard
//
//  Created by IACD-Air-7 on 2021/04/28.
//

import SwiftUI

struct Portfolio: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct Portfolio_Previews: PreviewProvider {
    static var previews: some View {
        Portfolio()
    }
}
