//
//  URLsessionApp.swift
//  URLsession
//
//  Created by IACD-Air-7 on 2021/06/09.
//

import SwiftUI

@main
struct URLsessionApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
