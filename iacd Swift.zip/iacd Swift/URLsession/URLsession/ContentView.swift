//
//  ContentView.swift
//  URLsession
//
//  Created by IACD-Air-7 on 2021/06/09.
//

import SwiftUI
import Combine

struct ContentView: View {
    @ObservedObject var fetcher = MovieFetcher()
    var body: some View {
        VStack {
            List(fetcher.movies) { movie in
                VStack (alignment: .leading) {
                    Text(movie.name)
                    Text(movie.released)
                        .font(.system(size: 11))
                        .foregroundColor(Color.gray)
                }
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
