//
//  ShapeApp.swift
//  Shape
//
//  Created by IACD-Air-7 on 2021/05/28.
//

import SwiftUI

@main
struct ShapeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
