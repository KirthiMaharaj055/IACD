//
//  ContentView.swift
//  Shape
//
//  Created by IACD-Air-7 on 2021/05/28.
//

import SwiftUI

struct ContentView: View {
    
    struct MySquare: Shape {
        func path(in rect: CGRect) -> Path {
            var path = Path()
            
            path.move(to: CGPoint(x: rect.size.width, y: 0))
            path.addLine(to: CGPoint(x: rect.size.width, y: rect.size.width))
            path.addLine(to: CGPoint(x: 0, y: rect.size.width))
            path.addLine(to: CGPoint(x: 0, y: 0))
            path.closeSubpath()
            return path
        }
    }
    var body: some View {
        VStack {
            RoundedRectangle(cornerRadius: 20)
                .stroke(style: StrokeStyle(lineWidth: 7, lineCap: .butt, dash: [15], dashPhase: 2))
                .frame(width: 250, height: 100)
                .foregroundColor(.pink)
                .padding()
            Spacer()
            
            MySquare()
                .frame(width: 250, height: 250)
                .padding()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
