//
//  ContentView.swift
//  HistoricalLandmarks
//
//  Created by IACD-Air-7 on 2021/04/06.
//

import SwiftUI

struct ContentView: View {
    @State private var selection: Tab = .featured
    enum Tab {
        case featured
        case profiles
        case list
    }
    var body: some View {
        HStack {
            TabView(selection: $selection) {
                CategoryHome()
                    .tabItem {
                        Label("Category", systemImage: "globe")
                    }
                    .tag(Tab.featured)
                
                HistoryList()
                    .tabItem {
                        Label("Landmarks", systemImage: "list.bullet")
                    }
                    .tag(Tab.list)
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .environmentObject(ModelData())
    }
}
