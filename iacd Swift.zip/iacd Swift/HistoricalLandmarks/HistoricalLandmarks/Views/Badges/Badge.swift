//
//  Badge.swift
//  HistoricalLandmarks
//
//  Created by IACD-Air-7 on 2021/04/08.
//

import SwiftUI

struct Badge: View {
    static let rotationCount = 8
    
    var badgeSymbols: some View {
        ForEach(0..<Badge.rotationCount) { i in
            RotatedBadgeSymbol(
                angle: .degrees(Double(i) / Double(Badge.rotationCount)) * 360.0
            )
        }
        .opacity(0.5)
    }
    
    var body: some View {
        ZStack {
            BadgeBackground()
                .scaleEffect( 0.8, anchor: .bottomTrailing)
            Image(systemName: "h.circle")
                .resizable()
                .opacity(0.5)
                .scaleEffect(0.2)
            
            GeometryReader { geometry in
                badgeSymbols
                    .scaleEffect(1.0 / 3.0, anchor: .center)
                    .position(x: geometry.size.width / 3.0, y: (2.0 / 6.0) * geometry.size.height)
            }
        }
        .scaledToFit()
    }
}

struct Badge_Previews: PreviewProvider {
    static var previews: some View {
        Badge()
    }
}
