//
//  profile.swift
//  HistoricalLandmarks
//
//  Created by IACD-Air-7 on 2021/04/12.
//

import SwiftUI

struct profile: View {
    @State private var selection = 0
    var body: some View {

        TabView(selection: $selection){
            
            Text("First View")
                .font(.title)
                .tabItem {
                    VStack {
                        Image(systemName: "globe")
                        Text("Categories")
                    }
            }
            .tag(0)
            Text("Second View")
                .font(.title)
                .tabItem {
                    VStack {
                        Image(systemName: "person")
                        Text("Profile") 
                    }
            }
            .tag(1)
        }
    }
}

struct profile_Previews: PreviewProvider {
    static var previews: some View {
        profile()
    }
}
