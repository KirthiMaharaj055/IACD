//
//  FeatureCard.swift
//  HistoricalLandmarks
//
//  Created by IACD-Air-7 on 2021/04/13.
//

import SwiftUI

struct FeatureCard: View {
    var history : Landmark
    
    var body: some View {
        history.featureImage?
            .resizable()
            .aspectRatio(3 / 2, contentMode: .fit)
            .overlay(TextOverlay(history: history))
    }
}
struct TextOverlay: View {
    var history: Landmark

    var gradient: LinearGradient {
        LinearGradient(
            gradient: Gradient(
            colors: [Color.black.opacity(0.8), Color.black.opacity(0)]),
            startPoint: .bottom,
            endPoint: .center)
    }

    var body: some View {
        ZStack(alignment: .bottomLeading) {
            Rectangle().fill(gradient)
            VStack(alignment: .leading) {
                Text(history.name)
                    .font(.title)
                    .bold()
                Text(history.placeType)
            }
            .padding()
        }
        .foregroundColor(.accentColor)
    }
}

struct FeatureCard_Previews: PreviewProvider {
    static var previews: some View {
        FeatureCard(history: ModelData().features[0])
    }
}
