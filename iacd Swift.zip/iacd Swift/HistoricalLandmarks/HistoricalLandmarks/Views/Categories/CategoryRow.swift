//
//  CategoryRow.swift
//  HistoricalLandmarks
//
//  Created by IACD-Air-7 on 2021/04/12.
//

import SwiftUI

struct CategoryRow: View {
    var categoryName: String
    var items: [Landmark]
    
    var body: some View {
        VStack(alignment: .leading){
            Text(categoryName)
                .font(.headline)
                .padding(.leading, 15)
                .padding(.top, 5)
            ScrollView(.horizontal, showsIndicators: false) {
            HStack(alignment: .top, spacing: 0) {
                ForEach(items) {
                    history in
                    NavigationLink(destination: HistoryDetail(history: history)) {
                        CategoryItem(history: history)
                    }
                }
            }
        }.frame(height: 185)
            .aspectRatio(contentMode: .fill)
        }
        
    }
}

struct CategoryRow_Previews: PreviewProvider {
    static var historicals = ModelData().historicals
    static var previews: some View {
        CategoryRow(categoryName: historicals[0].category.rawValue,
                    items: Array(historicals.prefix(4)))
    }
}
