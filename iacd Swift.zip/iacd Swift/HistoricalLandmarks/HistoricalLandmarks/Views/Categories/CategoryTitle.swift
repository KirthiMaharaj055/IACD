//
//  CategoryTitle.swift
//  HistoricalLandmarks
//
//  Created by IACD-Air-7 on 2021/05/12.
//

import SwiftUI

struct CategoryTitle: View {
    
    var body: some View {
        ZStack {
            Image("pexels1")
                .resizable()
                .frame(width: 300, height: 80, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                .aspectRatio(contentMode: .fit)
                .mask(Text("Historical Landmark"))
                .font(.system(size: 25, weight: .heavy, design: .monospaced))
                .shadow(radius: 10)
        }
    }
}

struct CategoryTitle_Previews: PreviewProvider {
    static var previews: some View {
        CategoryTitle()
    }
}
