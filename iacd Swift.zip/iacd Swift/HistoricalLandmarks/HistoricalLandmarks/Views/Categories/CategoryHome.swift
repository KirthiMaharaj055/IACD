//
//  CategoryHome.swift
//  HistoricalLandmarks
//
//  Created by IACD-Air-7 on 2021/04/09.
//

import SwiftUI

struct CategoryHome: View {
    @EnvironmentObject var modelData: ModelData
    @State private var showinggrid = false

    var body: some View {
        NavigationView {
           
                List {
                    PageView(pages: modelData.features.map { FeatureCard(history: $0) })
                        .aspectRatio(3 / 2, contentMode: .fit)
                        .listRowInsets(EdgeInsets())
                    ForEach(modelData.categories.keys.sorted(), id: \.self){
                        key in
                    CategoryRow(categoryName: key, items: modelData.categories[key]!)
                    }
                    .listRowInsets(EdgeInsets())
                }
                .listStyle(InsetListStyle())
                .navigationTitle("Category")
                .padding(.horizontal)
                .toolbar{
                    HStack(alignment: .center){
                        CategoryTitle()
                            .padding()
                        Button(action : {
                            withAnimation{
                            showinggrid.toggle()
                            }
                        }){
                            Image(systemName: showinggrid ? "rectangle.grid.1x2.fill" : "square.grid.2x2.fill")
                                .foregroundColor(.black).font(.title2)
                        }
                    }
                }
                .sheet(isPresented: $showinggrid) {
                    HistoryList()
                    .environmentObject(modelData)
                }
            
            
        }
    }
    
    
}

struct CategoryHome_Previews: PreviewProvider {
    static var previews: some View {
        CategoryHome()
            .environmentObject(ModelData())
    }
}
