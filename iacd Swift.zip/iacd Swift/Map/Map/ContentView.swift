//
//  ContentView.swift
//  Map
//
//  Created by IACD-Air-7 on 2021/06/02.
//

import SwiftUI
import MapKit

struct ContentView: View {
    @State private var region = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: -26.10864436793173, longitude: 28.05160399798577),
          span: MKCoordinateSpan(latitudeDelta: 0.02, longitudeDelta: 0.02))
    @State private var locations: [Location] = Location.getLocation()
    var body: some View {
        Map(coordinateRegion: $region, annotationItems: locations, annotationContent:  { (location) -> MapMarker in MapMarker(coordinate: location.coordinate, tint: .green)
        }).edgesIgnoringSafeArea(.all)
    }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
