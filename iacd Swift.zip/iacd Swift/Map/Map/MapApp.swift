//
//  MapApp.swift
//  Map
//
//  Created by IACD-Air-7 on 2021/06/02.
//

import SwiftUI

@main
struct MapApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
