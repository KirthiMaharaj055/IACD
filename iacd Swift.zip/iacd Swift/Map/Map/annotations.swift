//
//  annotations.swift
//  Map
//
//  Created by IACD-Air-7 on 2021/06/02.
//

import Foundation
import MapKit

struct Location {
    let id = UUID()
    let title: String
    let coordinate: CLLocationCoordinate2D
}

extension Location: Identifiable{
    
}
extension Location {
    static func getLocation() -> [Location] {
        return [
            Location(title: "Sandton City", coordinate: CLLocationCoordinate2D(latitude: -26.108711806459787, longitude: 28.052719796937136)),
            Location(title: "Mandela Square", coordinate: CLLocationCoordinate2D(latitude: -26.107237784050895, longitude: 28.05476900462667)),
            Location(title: "IStore Sandton", coordinate: CLLocationCoordinate2D(latitude:  -26.110012399034186, longitude: 28.048181499279167)),
        ]
    }
}
