//
//  StateTestView.swift
//  States
//
//  Created by IACD-Air-7 on 2021/05/06.
//

import SwiftUI

struct StateTestView: View {
    @State var state = TestObject() 
    var body: some View {
        
        VStack {
            Text("State: \(state.num)")
            Button("Increase state", action: {
                state.num += 1
                print("State: \(state.num)")
            })
            .onChange(of: state.num)  {
            newState in
                print("State: \(newState)")
            }
        }
       
    }
    
}

struct StateTestView_Previews: PreviewProvider {
    static var previews: some View {
        StateTestView()
    }
}
