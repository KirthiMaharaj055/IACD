//
//  anoter.swift
//  States
//
//  Created by IACD-Air-7 on 2021/05/10.
//

import SwiftUI

struct anoter: View {
    @EnvironmentObject var settings: GameSettings
    
    var body: some View {
        Text("My Score \(settings.word)")
           
    }
}

struct anoter_Previews: PreviewProvider {
    static var previews: some View {
        anoter()
    }
}
