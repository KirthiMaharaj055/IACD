//
//  ContentView.swift
//  States
//
//  Created by IACD-Air-7 on 2021/05/06.
//

import SwiftUI

struct ContentView: View {
    @StateObject var settings = GameSettings()
    var body: some View {
        
        NavigationView {
            VStack {
                Text("Score \(settings.score)")
                Button("Increase Score") {
                    settings.score += 1
                }

                NavigationLink(destination: ScoreView()) {
                    Text("Show Detail View")
                }
                NavigationLink(destination: anoter()) {
                    Text("Another")
                }
                
                Text("Highest Score \(settings.highScore)")
                Button("Highest Score") {
                    settings.highScore = settings.score
                }
                NavigationLink(destination: high()) {
                    Text("High Score")
                }
                   
            }.frame(height: 200)
        }
        .environmentObject(settings)

    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
