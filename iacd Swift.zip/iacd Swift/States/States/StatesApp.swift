//
//  StatesApp.swift
//  States
//
//  Created by IACD-Air-7 on 2021/05/06.
//

import SwiftUI

@main
struct StatesApp: App {
    @StateObject var environmentObject = TestObject1()
    var body: some Scene {
        WindowGroup {
            ContentView().environmentObject(environmentObject)
        }
    }
}
