//
//  high.swift
//  States
//
//  Created by IACD-Air-7 on 2021/05/10.
//

import SwiftUI

struct high: View {
    @EnvironmentObject var settings: GameSettings
    
    var body: some View {
        Text("My Score \(settings.highScore)")
           
    }
}

struct high_Previews: PreviewProvider {
    static var previews: some View {
        high()
    }
}
