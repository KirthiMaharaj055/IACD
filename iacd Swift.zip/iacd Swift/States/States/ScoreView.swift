//
//  ScoreView.swift
//  States
//
//  Created by IACD-Air-7 on 2021/05/10.
//

import SwiftUI

struct ScoreView: View {
    @EnvironmentObject var settings: GameSettings

       var body: some View {
           Text("Score: \(settings.score)")
       }
}

struct ScoreView_Previews: PreviewProvider {
    static var previews: some View {
        ScoreView()
    }
}
