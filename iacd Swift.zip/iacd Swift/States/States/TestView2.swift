//
//  TestView2.swift
//  States
//
//  Created by IACD-Air-7 on 2021/05/06.
//

import SwiftUI

struct TestView2: View {
    @StateObject var stateObject = TestObject1()
    
    var body: some View {
        VStack {
            NavigationView {
                NavigationLink(destination: TestView3(observedObject: stateObject)) {
                    
                    Text("Go").font(.largeTitle).bold()

                }
            }
            Text("State object: \(stateObject.num1)")
                .font(.largeTitle)
            Button(action: {
                stateObject.num1 += 1
            }) {
                Text("Increase state object")
            }
        }.padding(.bottom, 100)
        
       
    }
}


struct TestView2_Previews: PreviewProvider {
    static var previews: some View {
        TestView2()
    }
}
