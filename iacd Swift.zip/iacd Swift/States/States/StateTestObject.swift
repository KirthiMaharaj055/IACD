//
//  StateTestObject.swift
//  States
//
//  Created by IACD-Air-7 on 2021/05/06.
//

import Foundation

class TestObject1: ObservableObject {
 @Published var num1: Int = 0
}

class TestObject {
    var num: Int = 0
}

class TestObject2: ObservableObject {
 @Published var num2: Int = 0
    @Published var name: String = ""
}

class GameSettings: ObservableObject {
    @Published var score = 0
    @Published var word = "i'm your class"
    @Published var highScore = 0
}

