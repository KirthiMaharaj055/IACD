//
//  varible_inputApp.swift
//  varible input
//
//  Created by IACD-Air-7 on 2021/03/30.
//

import SwiftUI

@main
struct varible_inputApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
