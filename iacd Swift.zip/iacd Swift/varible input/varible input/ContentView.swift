//
//  ContentView.swift
//  varible input
//
//  Created by IACD-Air-7 on 2021/03/30.
//

import SwiftUI

struct ContentView: View {
    @State private var name : String = " "
    var body: some View {
        
        VStack(alignment: .leading) {
            TextField("Enter your name", text: $name)
            Text("Hello, \(name)!")
            
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
