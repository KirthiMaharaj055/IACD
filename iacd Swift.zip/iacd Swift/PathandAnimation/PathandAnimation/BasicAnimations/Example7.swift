//
//  Example7.swift
//  PathandAnimation
//
//  Created by IACD-Air-7 on 2021/06/11.
//

import SwiftUI

struct Example7: View {
    @State private var bounceBall: Bool = false
    @State private var hiddenText: String = "Kick the ball!"
    var body: some View {
        VStack {
            Image("1024px-Soccerball.svg")
                .resizable()
                .frame(width: 150, height: 150)
                .foregroundColor(.black)
                .clipShape(Circle())
                .offset(y: bounceBall ? -200 : 200)
                .onTapGesture {
                    self.bounceBall.toggle()
                    self.hiddenText = ""
                }
                .animation(Animation.interpolatingSpring(stiffness: 90, damping: 1.5).repeatForever(autoreverses: false))
        }
    }
}

struct Example7_Previews: PreviewProvider {
    static var previews: some View {
        Example7()
    }
}
