//
//  Example11.swift
//  PathandAnimation
//
//  Created by IACD-Air-7 on 2021/06/14.
//

import SwiftUI

struct Example11: View {
    @State private var location: CGPoint = CGPoint(x: 50, y: 50)
    @State private var fingerLocation: CGPoint? // 1
    
    var simpleDrag: some Gesture {
        DragGesture()
            .onChanged { value in
                self.location = value.location
            }
    }
    var fingerDrag: some Gesture { // 2
        DragGesture()
            .onChanged { value in
                self.fingerLocation = value.location
            }
            .onEnded { value in
                self.fingerLocation = nil
            }
    }
    var body: some View {
        ZStack { // 3
            RoundedRectangle(cornerRadius: 10)
                .foregroundColor(.pink)
                .frame(width: 100, height: 100)
                .position(location)
                .gesture( simpleDrag.simultaneously(with: fingerDrag) )// 4
                if let fingerLocation = fingerLocation { // 5
                    Circle()
                        .stroke(Color.green, lineWidth: 2)
                        .frame(width: 44, height: 44)
                        .position(fingerLocation)
                }
            VStack{
                Spacer()
                Text("X = \(location.x) y =\(location.y)")
                    .font(.title2)
                    .fontWeight(.bold)
                    .alignmentGuide(.bottom){
                        d in d[.bottom] + 8
                        
                    }
            }
        }
    }
}
struct Example11_Previews: PreviewProvider {
    static var previews: some View {
        Example11()
    }
}
