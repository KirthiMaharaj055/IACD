//
//  Example8.swift
//  PathandAnimation
//
//  Created by IACD-Air-7 on 2021/06/11.
//

import SwiftUI

struct Example8: View {
    @State private var zAxisRotation = false
    var body: some View {
        VStack {
            Image("1200px-Vinyl_record.svg")
                .resizable()
                .frame(width: 400, height: 400)
                .rotationEffect(.degrees(zAxisRotation ? 360*4 : 0), anchor: .center)
                .animation(Animation.linear(duration: 3).repeatCount(1))
                .onTapGesture { self.zAxisRotation.toggle()
                }
            Text("Tap the vinyl to make it spin!")
        }
    }
}

struct Example8_Previews: PreviewProvider {
    static var previews: some View {
        Example8()
    }
}
