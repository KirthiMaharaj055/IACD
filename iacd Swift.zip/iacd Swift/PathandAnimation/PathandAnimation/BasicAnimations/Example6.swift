//
//  Example6.swift
//  PathandAnimation
//
//  Created by IACD-Air-7 on 2021/06/11.
//

import SwiftUI

struct Example6: View {
    //for first tap me
    @State private var hidden = false
    // for second tap me
    @State private var hasOffset = false
    // for third tap me
    @Namespace private var animation
    @State private var isFlipped = false
    var body: some View {
        VStack{
            Button("Tap Me 1") {
                self.hidden = true
            }.opacity(hidden ? 0 : 1)
                .animation(.easeInOut(duration: 2))
                .padding()
            Button("Tap Me 2") {
                withAnimation(.interpolatingSpring(mass: 1,stiffness: 80,damping: 4,initialVelocity: 0)) {
                    self.hasOffset.toggle()
                }
            }.offset(y: hasOffset ? 40 : 0)
                .padding()
            HStack {
                if isFlipped {
                    Circle()
                        .fill(Color.blue)
                        .frame(width: 50, height: 50)
                        .matchedGeometryEffect(id: "Shape", in: animation)
                    Text("Tap me 3")
                        .matchedGeometryEffect(id: "Text", in: animation)
                } else {
                    Text("Tap me")
                        .matchedGeometryEffect(id: "Text", in: animation)
                    Circle()
                        .fill(Color.blue)
                        .frame(width: 50, height: 50)
                        .matchedGeometryEffect(id: "Shape", in: animation)
                }
            }.onTapGesture {
                withAnimation {
                    self.isFlipped.toggle()
                }
            }
        }
    }
}

struct Example6_Previews: PreviewProvider {
    static var previews: some View {
        Example6()
    }
}
