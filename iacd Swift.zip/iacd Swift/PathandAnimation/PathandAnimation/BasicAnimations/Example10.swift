//
//  Example10.swift
//  PathandAnimation
//
//  Created by IACD-Air-7 on 2021/06/14.
//

import SwiftUI

struct Example10: View {
    @State private var animate = false
    var body: some View {
        VStack {
            RoundedRectangle(cornerRadius: 5)
                .foregroundColor(.green)
                .frame(width: 200, height: 50)
                .overlay(ShowSize())
                .modifier(MyEffect(x: animate ? -87 : 90))
/*   RoundedRectangle(cornerRadius: 5)
        .foregroundColor(.blue)
        .frame(width: 300, height: 50)
        .overlay(ShowSize())
        .modifier(MyEffect(x: animate ? 10 : -10).ignoredByLayout())
*/
        }.onAppear {
            withAnimation(Animation.easeInOut(duration: 1.0).repeatForever()) {
                               self.animate = true
            }
        }
    }
}

struct MyEffect: GeometryEffect {
    var x: CGFloat = 0
    var y: CGFloat = 0
    var animatableData: CGFloat {
        get { x }
        set { x = newValue  }
    }
    var animatableData1: CGFloat {
        get { y }
        set { y = newValue }
    }
    func effectValue(size: CGSize) -> ProjectionTransform {
        return ProjectionTransform(CGAffineTransform(translationX: x, y: 0))
    }
}

struct ShowSize: View {
    var body: some View {
        GeometryReader { proxy in
            Text("x = \(Int(proxy.frame(in: .global).minX))")
                .foregroundColor(.white)
            }
    }
                
    struct ShowSizey: View {
        var body: some View {
            GeometryReader { proxy in
                Text("y = \(Int(proxy.frame(in: .global).minY))")
                    .foregroundColor(.white)
            }
        }
    }
}

struct Example10_Previews: PreviewProvider {
    static var previews: some View {
        Example10()
    }
}
