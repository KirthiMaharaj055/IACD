//
//  Example1.swift
//  PathandAnimation
//
//  Created by IACD-Air-7 on 2021/06/10.
//

import SwiftUI

struct Example1: View {
    var body: some View {
        Path { path in
            path.move(to: CGPoint(x: 200, y: 200))
            path.addLine(to: CGPoint(x: 50, y: 600))
            path.addLine(to: CGPoint(x: 360, y: 600))
            path.addLine(to: CGPoint(x: 200, y: 200))
        }.foregroundColor(.blue)
    }
}

struct Example1_Previews: PreviewProvider {
    static var previews: some View {
        Example1()
    }
}
