//
//  Example4.swift
//  PathandAnimation
//
//  Created by IACD-Air-7 on 2021/06/11.
//

import SwiftUI

struct Example4: View {
    @State private var degrees = 0.0
    var body: some View {
        VStack {
            Button("Animate..!") {
                withAnimation {
                    self.degrees += 360
                }
            }.padding(20)
            .background(Color.blue.opacity(0.8))
            .foregroundColor(Color.white)
            .rotation3DEffect(.degrees(degrees), axis: (x: 1, y: 1, z: 1))
            Text("SwiftUI Animations")
                .rotation3DEffect(.degrees(45), axis: (x: 1, y: 0, z: 0))
        }
    }
}

struct Example4_Previews: PreviewProvider {
    static var previews: some View {
        Example4()
    }
}
