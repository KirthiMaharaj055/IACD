//
//  Example9.swift
//  PathandAnimation
//
//  Created by IACD-Air-7 on 2021/06/14.
//

import SwiftUI

struct Example9: View {
    @State var textColor = Color.blue
    @State var showOverlay = false
    
    var body: some View {
        Text("Hello World")
            .frame(width: 100, height: 100)
            .background(textColor)
            .onTapGesture {
                self.showOverlay.toggle()
            }
             .overlay(
            VStack {
                if self.showOverlay {
                    Circle()
                        .stroke(Color.red, lineWidth: 30)
                        .frame(width: 300, height: 300)
                        .onTapGesture { self.textColor = Color.red
                        }
                } else {
                    EmptyView()
                }
            })
    }
}

struct Example9_Previews: PreviewProvider {
    static var previews: some View {
        Example9()
    }
}
