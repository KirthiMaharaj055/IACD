//
//  PathandAnimationApp.swift
//  PathandAnimation
//
//  Created by IACD-Air-7 on 2021/06/10.
//

import SwiftUI

@main
struct PathandAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
