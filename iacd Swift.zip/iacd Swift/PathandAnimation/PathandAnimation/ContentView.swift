//
//  ContentView.swift
//  PathandAnimation
//
//  Created by IACD-Air-7 on 2021/06/10.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
            List {
                Section(header: Text("Drawings")) {
                    NavigationLink(destination: Example1(), label: {
                        LabelStyle(imageName: "one", text: "Your first drawing using Path")
                    })
                    NavigationLink(destination: Example2(), label: {
                        LabelStyle(imageName: "two", text: "More on Shapes")
                    })
                    NavigationLink(destination: Example3(), label: {
                        LabelStyle(imageName: "three", text: " Shapes overlapping")
                    })
                }
                Section(header: Text("Some 3D Examples")) {
                    NavigationLink(destination: Example4(), label: {
                        LabelStyle(imageName: "one", text: "A 3D effect")
                    })
                    NavigationLink(destination: Example5(), label: {
                        LabelStyle(imageName: "two", text: " rotating cube")
                    })
                    NavigationLink(destination: Example9(), label: {
                        LabelStyle(imageName: "three", text: "")
                    })
                }
                Section(header: Text("Basic Animations")) {
                    NavigationLink(destination: Example6(), label: {
                        LabelStyle(imageName: "1.circle.fill", text: "Tap Gestures")
                    })
                    NavigationLink(destination: Example7(), label: {
                        LabelStyle(imageName: "2.circle.fill", text: " A spring effect")
                    })
                    NavigationLink(destination: Example8(), label: {
                        LabelStyle(imageName: "3.circle.fill", text: " Spinning Animation")
                    })
                    NavigationLink(destination: Example10(), label: {
                        LabelStyle(imageName: "4.circle.fill", text: "Simple Drag")
                    })
                    NavigationLink(destination: Example11(), label: {
                        LabelStyle(imageName: "5.circle.fill", text: " Spinning Animation")
                    })
                }
            }.navigationBarTitle("SwiftUI Tutorial")
        }.listStyle(SidebarListStyle())
    }
}

struct LabelStyle: View {
    let imageName: String
    let text: String
    var body: some View {
        HStack {
            Image(imageName)
                .resizable()
                .scaledToFill()
                .frame(width: 60, height: 60)
                .overlay(RoundedRectangle(cornerRadius: 60)
                    .strokeBorder(style: StrokeStyle(lineWidth: 2))
                    .foregroundColor(Color.black))
                .cornerRadius(60)
                Text(text)
        }
    }
}
         
struct MyButton: View {
    let label: String
    var font: Font = .title
    var textColor: Color = .white
    let action: () -> ()
    var body: some View {
        Button(action: {
            self.action()
        }, label: {
            Text(label)
                .font(font)
                .padding(10)
                .frame(width: 70)
                .background(RoundedRectangle(cornerRadius: 10).foregroundColor(Color.green).shadow(radius: 2))
                .foregroundColor(textColor)
        })
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
