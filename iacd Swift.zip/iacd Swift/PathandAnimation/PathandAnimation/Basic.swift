//
//  Basic.swift
//  PathandAnimation
//
//  Created by IACD-Air-7 on 2021/06/10.
//

import SwiftUI

struct Basic: View {
    var body: some View {
        Image(systemName: "heart.fill")//.resizable()
            .frame(width: 100.0, height: 100)
            .clipShape(Circle())
            .shadow(radius: 50)
            .overlay(Circle().stroke(Color.red, lineWidth: 50))
    }
}

struct Basic_Previews: PreviewProvider {
    static var previews: some View {
        Basic()
    }
}
