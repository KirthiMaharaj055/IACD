//
//  LandmarksApp.swift
//  Landmarks
//
//  Created by IACD-Air-7 on 2021/03/24.
//

import SwiftUI

@main
struct LandmarksApp: App {
    @StateObject private var modelData = ModelData()
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(modelData)
        }
    }
}
